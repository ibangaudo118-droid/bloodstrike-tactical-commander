# Tactical Commander — Native Android Capture MVP

This is Phase 1 of the Blood Strike Tactical Commander.

## What this build does

1. Requests Android screen-capture permission using MediaProjection.
2. Starts a mediaProjection foreground service.
3. Captures the device display continuously.
4. Uses an ImageReader to prove frames are arriving.
5. Keeps the capture running while you open Blood Strike.

It does **not** understand the game yet.

## Build

GitHub Actions builds a debug APK automatically when files under `android/` change.

After the workflow finishes:
Actions → Build Android APK → Artifacts → tactical-commander-debug-apk.

## Architecture

Blood Strike
→ Android MediaProjection
→ ImageReader
→ Frame pipeline
→ AI Vision (next phase)
→ Tactical Decision Engine
→ Voice Commander (later)

## Android requirements

The capture service is declared as a `mediaProjection` foreground service. Modern Android versions require the corresponding foreground-service permission and user-approved screen capture before the service can capture the display.

Do not add a hidden or silent capture mechanism. The app should always show the Android capture consent UI and an ongoing notification while capture is active.
